/** The basic interfaces for rnio.
 *
 *  <p>The main class here is the {@link org.khelekore.rnio.NioHandler}.
 *
 * @since 1.0
 */
package org.khelekore.rnio;
